package com.example.client.module.modules;

import com.darkmagician6.eventapi.EventTarget;
import com.example.client.events.RenderEvent;
import com.example.client.language.Language;
import com.example.client.language.Text;
import com.example.client.module.AbstractModule;
import com.example.client.module.annotation.ModuleInfo;
import com.example.client.setting.annotation.SettingInfo;
import com.example.client.setting.settings.BooleanSetting;
import com.example.client.utils.PlayerUtils;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;

import java.awt.Color;

/**
 * CS2 风格的回合完成横幅。
 * 由 {@link #showRoundWin(int, long)} 在下一回合开始时触发；渲染本身只发生在 HUD 阶段。
 */
@ModuleInfo(name = {
        @Text(label = "CS2 Round HUD", language = Language.English),
        @Text(label = "CS2 回合横幅", language = Language.Chinese)
}, enable = true)
public class Cs2RoundHud extends AbstractModule {
    /** 横幅从中心横向撑开的阶段：白底 + 左右两条亮色竖 bar。 */
    private static final long EXPAND_MS = 480L;
    /** 横幅展开完成后的标题故障切片动画。 */
    private static final long GLITCH_MS = 390L;
    private static final long SUBTITLE_START_MS = EXPAND_MS + GLITCH_MS;
    private static final long HOLD_UNTIL_MS = 4_050L;
    private static final long OUTRO_MS = 520L;
    private static final long TOTAL_MS = HOLD_UNTIL_MS + OUTRO_MS;
    private static final long PREVIEW_INTERVAL_MS = 6_500L;

    private static final Color BACKGROUND = new Color(53, 48, 31, 238);
    private static final Color INNER_BACKGROUND = new Color(80, 72, 42, 115);
    private static final Color BORDER = new Color(213, 171, 67, 255);
    private static final Color BORDER_DIM = new Color(128, 101, 41, 255);
    private static final Color TITLE = new Color(246, 203, 91, 255);
    private static final Color SUBTITLE = new Color(235, 235, 225, 255);
    private static final Color DECORATION = new Color(255, 213, 103, 255);
    private static final Color PATTERN = new Color(255, 226, 139, 18);
    private static final Color OPENING_WHITE = new Color(245, 250, 255, 255);
    private static final Color OPENING_BAR = new Color(134, 220, 255, 255);
    private static final Color GLITCH_WHITE = new Color(235, 250, 255, 255);
    /** 与 DamageNumbers 相同的 TTF 字体。 */
    private static final FontDescription DAMAGE_FONT =
            new FontDescription.Resource(Identifier.fromNamespaceAndPath("zombies-mod", "damage"));

    @SettingInfo(name = {
            @Text(label = "Only In Zombies", language = Language.English),
            @Text(label = "仅在僵尸末日里", language = Language.Chinese)
    })
    public static final BooleanSetting onlyGame = new BooleanSetting(true);

    @SettingInfo(name = {
            @Text(label = "Preview in Singleplayer", language = Language.English),
            @Text(label = "单人游戏预览", language = Language.Chinese)
    })
    public static final BooleanSetting previewInSingleplayer = new BooleanSetting(false);

    private static RoundResult activeResult;
    private static long lastPreviewMs;

    private record RoundResult(int round, long goldDelta, long startedMs, boolean preview) {
    }

    public Cs2RoundHud() {
        registerSetting(onlyGame, previewInSingleplayer);
    }

    /** 播放一次真实的“上一回合完成”横幅。 */
    public static void showRoundWin(int round, long goldDelta) {
        if (round < 1) return;
        activeResult = new RoundResult(round, goldDelta, System.currentTimeMillis(), false);
    }

    /** 调试/单人预览入口。 */
    public static void showPreview() {
        activeResult = new RoundResult(30, 1_250L, System.currentTimeMillis(), true);
    }

    @Override
    protected void onDisable() {
        activeResult = null;
    }

    @EventTarget
    public void onRender(RenderEvent event) {
        if (mc.player == null || mc.level == null) return;

        long now = System.currentTimeMillis();
        boolean inZombies = PlayerUtils.isInHypZombies();
        boolean previewEnvironment = mc.hasSingleplayerServer() && previewInSingleplayer.getValue();

        if (previewEnvironment && (activeResult == null || now - lastPreviewMs >= PREVIEW_INTERVAL_MS)) {
            lastPreviewMs = now;
            showPreview();
        }

        if (activeResult == null) return;
        if (onlyGame.getValue() && !inZombies && !activeResult.preview()) {
            activeResult = null;
            return;
        }

        long age = now - activeResult.startedMs();
        if (age < 0 || age >= TOTAL_MS) {
            activeResult = null;
            return;
        }

        renderBanner(event.getGuiGraphicsExtractor(), activeResult, age);
    }

    private void renderBanner(GuiGraphicsExtractor graphics, RoundResult result, long ageMs) {
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        // 参考全屏 CS2 图：横幅约为屏幕宽度的三分之一，比例紧凑而非占满顶部。
        int bannerWidth = Math.clamp((int) (screenWidth * 0.33F), 280, 360);
        bannerWidth = Math.min(bannerWidth, screenWidth - 20);
        int bannerHeight = 56;
        int targetY = 42;

        float outro = progress(ageMs, HOLD_UNTIL_MS, OUTRO_MS);
        float alpha = 1.0F - easeInCubic(outro);
        int x = (screenWidth - bannerWidth) / 2;
        int y = targetY;
        float expand = easeOutCubic(progress(ageMs, 0L, EXPAND_MS));

        // CS2 风格开场：横向由 0 扩至完整宽度，白色主体只带两条 cyan 竖 bar。
        if (expand < 1.0F) {
            drawOpeningBars(graphics, screenWidth / 2, y, bannerWidth, bannerHeight, expand, alpha);
            return;
        }

        float settled = easeOutCubic(progress(ageMs, EXPAND_MS, 160L));
        float glitch = progress(ageMs, EXPAND_MS, GLITCH_MS);
        if (glitch < 1.0F) {
            drawWholeBannerGlitch(graphics, x, y, bannerWidth, bannerHeight, alpha, glitch, ageMs);
            // 文字独立于矩形 glitch 层：始终稳定，不参与横向撕裂。
            drawBannerOverlay(graphics, x, y, bannerWidth, result, alpha, ageMs, false);
        } else {
            drawTopMarkers(graphics, screenWidth / 2, y, settled, alpha);
            drawBannerContents(graphics, x, y, bannerWidth, bannerHeight, result, alpha, ageMs, true);
        }
    }

    /** 正常状态下的一整张横幅；glitch 时也会被切片重复调用。 */
    private void drawBannerContents(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                                    RoundResult result, float alpha, long ageMs, boolean showSubtitle) {
        drawPanel(graphics, x, y, width, height, alpha, ageMs);
        drawBannerOverlay(graphics, x, y, width, result, alpha, ageMs, showSubtitle);
    }

    /** 标题、箭头与副标题：不进入背景的 glitch 切片。 */
    private void drawBannerOverlay(GuiGraphicsExtractor graphics, int x, int y, int width,
                                   RoundResult result, float alpha, long ageMs, boolean showSubtitle) {
        drawDamageCentered(graphics, "ZOMBIES  ROUND CLEARED", x + width / 2F, y + 24F,
                TITLE, alpha);

        float arrows = easeOutCubic(progress(ageMs, EXPAND_MS + 120L, 360L));
        drawSideChevron(graphics, "»", x + 16, y + 25, -1, arrows, alpha);
        drawSideChevron(graphics, "«", x + width - 16 - mc.font.width("«"), y + 25, 1, arrows, alpha);

        if (!showSubtitle) return;
        float subtitleProgress = easeOutCubic(progress(ageMs, SUBTITLE_START_MS, 360L));
        drawDamageCentered(graphics, subtitle(result), x + width / 2F, y + 48F,
                SUBTITLE, alpha * subtitleProgress);
    }

    /**
     * 横幅完成展开后的整块 glitch：每条水平切片重新画完整面板，
     * 所以背景、金边和装饰纹理会一起被横向撕裂；文字在独立覆盖层保持稳定。
     */
    private void drawWholeBannerGlitch(GuiGraphicsExtractor graphics, int x, int y, int width, int height,
                                       float alpha, float progress, long ageMs) {
        drawPanel(graphics, x, y, width, height, alpha * 0.20F, ageMs);

        int cursorY = y;
        int slice = 0;
        long phase = (ageMs - EXPAND_MS) / 34L;
        float intensity = 1.0F - progress * 0.72F;
        while (cursorY < y + height) {
            int sliceHeight = 2 + (int) ((phase + slice * 3L) % 5L);
            int endY = Math.min(y + height, cursorY + sliceHeight);
            int offset = Math.round(glitchOffset(phase, slice) * intensity * 1.8F);

            graphics.enableScissor(x - 18, cursorY, x + width + 18, endY);
            drawPanel(graphics, x + offset, y, width, height, alpha, ageMs);

            if ((slice & 1) == 0) {
                int tearStart = x + width / 4 + Math.abs(offset) * 3;
                int tearEnd = Math.min(x + width, tearStart + width / 3);
                graphics.fill(tearStart, cursorY, tearEnd, endY,
                        withAlpha(GLITCH_WHITE, alpha * intensity * 0.30F));
            }
            graphics.disableScissor();

            cursorY = endY;
            slice++;
        }
    }

    private void drawOpeningBars(GuiGraphicsExtractor graphics, int centerX, int y, int fullWidth, int height,
                                 float expand, float alpha) {
        int currentWidth = Math.max(1, Math.round(fullWidth * expand));
        int x = centerX - currentWidth / 2;
        int right = x + currentWidth;
        int barWidth = Math.min(4, Math.max(1, currentWidth / 2));

        graphics.fill(x, y, right, y + height, withAlpha(OPENING_WHITE, alpha));
        graphics.fill(x, y, x + barWidth, y + height, withAlpha(OPENING_BAR, alpha));
        graphics.fill(right - barWidth, y, right, y + height, withAlpha(OPENING_BAR, alpha));
    }

    private void drawPanel(GuiGraphicsExtractor graphics, int x, int y, int width, int height, float alpha, long ageMs) {
        graphics.fill(x, y, x + width, y + height, withAlpha(BACKGROUND, alpha));
        graphics.fill(x + 4, y + 4, x + width - 4, y + height - 4, withAlpha(INNER_BACKGROUND, alpha));

        graphics.fill(x, y, x + width, y + 1, withAlpha(BORDER, alpha));
        graphics.fill(x, y + height - 1, x + width, y + height, withAlpha(BORDER_DIM, alpha));
        graphics.fill(x, y, x + 1, y + height, withAlpha(BORDER_DIM, alpha));
        graphics.fill(x + width - 1, y, x + width, y + height, withAlpha(BORDER, alpha));

        for (int stripeX = x + 8; stripeX < x + width - 8; stripeX += 5) {
            graphics.fill(stripeX, y + 5, stripeX + 1, y + height - 5, withAlpha(PATTERN, alpha));
        }

    }

    private void drawTopMarkers(GuiGraphicsExtractor graphics, int centerX, int panelY, float intro, float alpha) {
        int markerY = Math.round(panelY - 12 + (1.0F - intro) * 6.0F);
        int size = 6;
        int gap = 10;
        for (int i = -1; i <= 1; i++) {
            int x = centerX + i * gap - size / 2;
            Color color = i == 0 ? BORDER : SUBTITLE;
            graphics.fill(x, markerY, x + size, markerY + size, withAlpha(color, alpha));
            graphics.fill(x + 1, markerY + 1, x + size - 1, markerY + size - 1,
                    withAlpha(BACKGROUND, alpha));
        }
    }

    private void drawSideChevron(GuiGraphicsExtractor graphics, String text, int x, int y, int direction,
                                 float progress, float alpha) {
        int offset = Math.round((1.0F - progress) * 13.0F * direction);
        graphics.text(mc.font, text, x + offset, y, withAlpha(DECORATION, alpha * progress), true);
    }

    private void drawDamageCentered(GuiGraphicsExtractor graphics, String text, float centerX, float centerY,
                                    Color color, float alpha) {
        Component component = Component.literal(text).withStyle(style -> style.withFont(DAMAGE_FONT));
        int width = mc.font.width(component);
        int textAlpha = Math.clamp(Math.round(alpha * 255.0F), 0, 255);
        DamageNumbers.drawGradientText(graphics, component, centerX, centerY, width,
                DamageNumbers.DAMAGE_FONT_HEIGHT, 1.0F, color, color, textAlpha);
    }

    private static int glitchOffset(long phase, int slice) {
        long hash = (phase + 17L) * 1_103_515_245L + (slice + 7L) * 12_345L;
        return (int) ((hash >>> 16) % 17L) - 8;
    }

    private static String subtitle(RoundResult result) {
        String gold = result.goldDelta() > 0 ? "  +" + String.format("%,d", result.goldDelta()) + " GOLD" : "";
        return "ROUND " + result.round() + " COMPLETE" + gold;
    }

    private static float progress(long elapsedMs, long delayMs, long durationMs) {
        return Math.clamp((elapsedMs - delayMs) / (float) durationMs, 0.0F, 1.0F);
    }

    private static float easeOutCubic(float value) {
        float inverse = 1.0F - value;
        return 1.0F - inverse * inverse * inverse;
    }

    private static float easeInCubic(float value) {
        return value * value * value;
    }

    private static int withAlpha(Color color, float alpha) {
        int resultAlpha = Math.clamp(Math.round(color.getAlpha() * alpha), 0, 255);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), resultAlpha).getRGB();
    }
}
